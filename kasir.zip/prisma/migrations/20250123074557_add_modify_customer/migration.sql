/*
  Warnings:

  - You are about to drop the column `kode_pos` on the `customer` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `customer` DROP COLUMN `kode_pos`;
