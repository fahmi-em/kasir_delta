-- AlterTable
ALTER TABLE `ordersatuan` MODIFY `ukuran` VARCHAR(191) NULL;
