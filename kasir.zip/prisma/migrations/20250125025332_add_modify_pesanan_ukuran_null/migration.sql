-- AlterTable
ALTER TABLE `pesanan` MODIFY `ukuran` VARCHAR(191) NULL;
